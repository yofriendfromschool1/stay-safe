# SeroXen Removal Tool

This tool is used to find and remove all traces of the SeroXen Remote Administration Trojan.

Tested on version **v3.0.6** (latest at the time of writing).
This tool will most likely stop working if SeroXen gets updated to **v3.0.7**, but might still be able to detect the presence of the malware.
